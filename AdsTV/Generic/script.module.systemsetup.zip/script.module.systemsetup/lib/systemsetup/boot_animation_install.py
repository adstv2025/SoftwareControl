# -----------------------------------------------------------------------------
# Name: Nejib MELKI
# Project: Install boot animation at device startup
# File: boot_animation_install.py
#
# Copyright (c) 2025 Nejib MELKI
# All rights reserved.
#
# This software and its source code are the property of Nejib MELKI. Unauthorized
# copying, modification, distribution, or use of this software, in whole or in
# part, is strictly prohibited without the explicit written permission of 
# Nejib MELKI.
#
# This software is provided 'as-is', without any express or implied warranty.
# In no event shall the author be held liable for any damages arising from
# the use of this software.
# -----------------------------------------------------------------------------

import os
import xbmcgui
import shutil
import xbmcvfs
import platform
import xbmc

class BootAnimationInstall:
    def __init__(self, selected_directory):
        self.selected_directory = selected_directory
    
    def change_boot_animation(self, image_path):
        """
        Change the Android system's boot animation to a custom one.
        
        Args:
            image_path (str): Path to the new boot animation (.zip file).
        """
        # Paths to the system boot animation locations
        boot_animation_paths = [
            '/system/media/bootanimation.zip',
            '/data/local/bootanimation.zip'
        ]
        
        # Check if the image file exists
        if not os.path.exists(image_path):
            print(f"Error: Boot animation file '{image_path}' does not exist.")
            xbmcgui.Dialog().ok("Error", f"Boot animation file '{image_path}' does not exist.")
            return
        
        # Check if the script is run with root permissions
        #if not is_root():
        #    print("Error: This script requires root permissions.")
        #    return

        # Try replacing the boot animation
        for path in boot_animation_paths:
            if os.path.exists(path):
                try:
                    # Backup the existing boot animation
                    backup_path = path + ".bak"
                    shutil.copy2(path, backup_path)
                    print(f"Backup created: {backup_path}")

                    # Replace the boot animation with the custom one
                    shutil.copy2(image_path, path)
                    print(f"Boot animation successfully replaced: {path}")
                    xbmcgui.Dialog().ok("Info", f"Boot animation successfully replaced: {path}")
                    return
                except Exception as e:
                    print(f"Error while replacing the boot animation: {e}")
                    xbmcgui.Dialog().ok("Error", f"Error while replacing the boot animation: {e}")
                    return
