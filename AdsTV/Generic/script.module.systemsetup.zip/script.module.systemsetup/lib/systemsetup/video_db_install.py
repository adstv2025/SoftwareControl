# -----------------------------------------------------------------------------
# Name: Nejib MELKI
# Project: Install video database at first install
# File: video_db_install.py
#
# Copyright (c) 2025 Nejib MELKI
# All rights reserved.
#
# This software and its source code are the property of Nejib MELKI. Unauthorized
# copying, modification, distribution, or use of this software, in whole or in
# part, is strictly prohibited without the explicit written permission of 
# Nejib MELKI.
#
# This software is provided 'as-is', without any express or implied warranty.
# In no event shall the author be held liable for any damages arising from
# the use of this software.
# -----------------------------------------------------------------------------

import os
import xbmcgui
import shutil
import xbmcvfs
import platform
import xbmc

VIDEO_DB_DIRECTORY_NAME = "AdsTV"
DESTINATION_PATH = "/sdcard/data/" 

class VideoDbInstall:
    def __init__(self, selected_directory):
        self.selected_directory = selected_directory
    
    def copy_video_directory(self):
        source_path = os.path.join(self.selected_directory, VIDEO_DB_DIRECTORY_NAME)
        if os.path.exists(source_path):
            destination_path = self.get_destination_path()
            if os.path.exists(destination_path):
                shutil.rmtree(destination_path)
            os.makedirs(destination_path, exist_ok=True)

            # First, create all empty directories manually
            for root, dirs, _ in os.walk(source_path):
                for dir_name in dirs:
                    empty_dir_path = os.path.join(DESTINATION_PATH, os.path.relpath(os.path.join(root, dir_name), source_path))
                    os.makedirs(empty_dir_path, exist_ok=True)  # Create empty directories
                    xbmc.log(f"Created directory {empty_dir_path} !!!!!", xbmc.LOGINFO)

            shutil.copytree(source_path, destination_path, dirs_exist_ok=True)
        else:
            xbmc.log(f"Video database {source_path} doesn't exist", xbmc.LOGERROR)
    
    def get_destination_path(self):
        os_name = platform.system()
        if os_name == "Linux" and "ANDROID_ROOT" in os.environ:
            return "/sdcard/data/AdsTV"
        return "D:/Versions/AdsTV"

