# -----------------------------------------------------------------------------
# Name: Nejib MELKI
# Project: Install splash image at kodi startup
# File: splash_install.py
#
# Copyright (c) 2025 Nejib MELKI
# All rights reserved.
#
# This software and its source code are the property of Nejib MELKI. Unauthorized
# copying, modification, distribution, or use of this software, in whole or in
# part, is strictly prohibited without the explicit written permission of 
# Nejib MELKI.
#
# This software is provided 'as-is', without any express or implied warranty.
# In no event shall the author be held liable for any damages arising from
# the use of this software.
# -----------------------------------------------------------------------------

import os
import xbmcgui
import shutil
import xbmcvfs
import platform
import xbmc

class SplashInstall:
    def __init__(self, selected_directory):
        self.selected_directory = selected_directory
    
    def get_os_name(self):
        """
        Detects and returns the current operating system name.
        """
        os_name = platform.system()
        if os_name == "Linux" and "ANDROID_ROOT" in os.environ:
            return "Android"
        return os_name

    def change_kodi_splash(self, image_path):
        """
        Change Kodi's startup splash screen image.

        Args:
            image_path (str): Path to the new splash screen image.
        """
        kodi_dir = self.find_kodi_data_directory()

        if kodi_dir is None:
            print("Error: Kodi data directory not found.")
            xbmcgui.Dialog().ok("Error", "Kodi data directory not found.")
            return

        # Target splash image path
        os_name = self.get_os_name()
        
        if os_name == "Android":
            splash_image_path = os.path.join(kodi_dir, "Splash.png")
        else:
            splash_image_path = os.path.join(kodi_dir, "Splash.jpg")

        # Validate input
        if not os.path.exists(image_path):
            print(f"Error: Image file '{image_path}' does not exist.")
            xbmcgui.Dialog().ok("Error", f"Image file '{image_path}' does not exist.")
            return

        # Replace the splash image
        try:
            # Backup the original splash image, if it exists
            #if os.path.exists(splash_image_path):
            #    backup_path = os.path.join(kodi_dir, "Splash_backup.png")
            #    shutil.copy2(splash_image_path, backup_path)
            #    print(f"Backup created: {backup_path}")

            # Copy the new image to replace the splash screen
            shutil.copy2(image_path, splash_image_path)
            #print(f"New splash screen image applied: {splash_image_path}")
            #xbmcgui.Dialog().ok("Info", f"New splash screen image applied: {splash_image_path}")
            xbmc.log(f"New splash screen image applied: {splash_image_path}", xbmc.LOGINFO)

        except Exception as e:
            print(f"Error while replacing the splash screen image: {e}")
            xbmcgui.Dialog().ok("Error", f"Error while replacing the splash screen image: {e}")

    def find_kodi_data_directory(self):
        """
        Dynamically search for the Kodi data directory on an Android device.
        
        Returns:
            str: The path to the Kodi data directory if found, or None if not found.
        """
        os_name = self.get_os_name()
        
        if os_name == "Android":
            possible_dirs = [
                '/sdcard/Android/data/org.xbmc.kodi/files/.kodi/media',  # Common location for Kodi on Android
                '/data/data/org.xbmc.kodi/files/.kodi/media',  # Another location on rooted devices
                '/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/media',  # Common path on some devices
            ]
        else:
            possible_dirs = [
                'C:/Program Files/Kodi/resources/skins/Confluence/media',  
                'D:/Program Files/Kodi/resources/skins/Confluence/media',
                'D:\Program Files (x86)\Kodi\media'
            ]

        
        for path in possible_dirs:
            if os.path.exists(path):
                return path
        
        return None  # Return None if no Kodi data directory is found
