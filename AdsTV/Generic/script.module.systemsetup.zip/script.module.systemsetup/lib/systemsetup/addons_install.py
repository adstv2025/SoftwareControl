# -----------------------------------------------------------------------------
# Name: Nejib MELKI
# Project: Addons install
# File: addons_install.py
#
# Copyright (c) 2025 Nejib MELKI
# All rights reserved.
#
# This software and its source code are the property of Nejib MELKI. Unauthorized
# copying, modification, distribution, or use of this software, in whole or in
# part, is strictly prohibited without the explicit written permission of 
# Nejib MELKI.
#
# This software is provided 'as-is', without any express or implied warranty.
# In no event shall the author be held liable for any damages arising from
# the use of this software.
# -----------------------------------------------------------------------------

import os
import shutil
import json
import xbmcgui
import xbmcvfs
import platform
import xbmc
import xbmcaddon
#import time

import sqlite3
import zipfile

ADDON_NAME_LIST = [
                    "script.module.systemsetup",
                    "script.module.addonssetup",
                    "script.module.upgrade",
                    "plugin.program.setup",
                    "plugin.program.refresh",
                    "service.autoplay",
                    "service.autoupdate",
#                    "service.watchdog",
                    "skin.AdsTV"
                  ]

class AddonsInstall:
    def __init__(self, version_directory):
        self.version_directory = version_directory
        self.output_path = xbmcvfs.translatePath('special://home/addons/') # Kodi's addon directory

    def get_zip_files(self, directory):
        """Returns a list of all .zip files in the selected directory."""
        if not os.path.exists(directory):
            return []  # Return empty list if directory doesn't exist
        
        return [f for f in os.listdir(directory) if f.lower().endswith('.zip')]

    def uninstall_addons_list(self):
    
        #Stop running services
        self.stop_services()
        
        #Disable all notifications
        #self.disable_all_notifications()
        #self.inspect_jsonrpc()
        
        # Retrieve .zip files in the given directory
        zip_files = self.get_zip_files(self.version_directory)

        for addon_name in reversed(ADDON_NAME_LIST):
            try:
                addon_name_zip = f"{addon_name}.zip"
                if addon_name_zip in zip_files:
                    self.uninstall_addon(addon_name)
                    #self.install_addon(addon_name)
                    self.enable_addon_in_db(addon_name, False)
            except Exception as e:
                xbmc.log(f"Failed to uninstall addon {addon_name}: {e}", xbmc.LOGERROR)

        time.sleep(30)

    def clear_disabled_addon_flags(self):
        try:
            userdata = xbmcvfs.translatePath('special://userdata/Database/')
            db_files = [f for f in os.listdir(userdata) if f.startswith('Addons') and f.endswith('.db')]

            if not db_files:
                xbmcgui.Dialog().notification("Kodi", "No addons database found.", xbmcgui.NOTIFICATION_ERROR)
                xbmc.log(f"No addons database found !!!!!", xbmc.LOGERROR)    
                return

            for db_file in db_files:
                full_path = os.path.join(userdata, db_file)
                backup_path = full_path + ".bak"
                shutil.copyfile(full_path, backup_path)
                os.remove(full_path)
                xbmc.log(f"Deleted {full_path} to reset addon flags.", xbmc.LOGINFO)

            xbmcgui.Dialog().notification("Kodi", "Addon state cleared. Restart Kodi.", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
            xbmc.log(f"Error clearing addon flags: {e}", xbmc.LOGERROR)    

    def install_addons_list(self):

        # Retrieve .zip files in the given directory
        zip_files = self.get_zip_files(self.version_directory)

        for addon_name in ADDON_NAME_LIST:
            try:
                addon_name_zip = f"{addon_name}.zip"
                if addon_name_zip in zip_files:
                    #self.uninstall_addon(addon_name)
                    self.install_addon(addon_name)
                    ###time.sleep(5)
                    ###self.enable_addon_in_db(addon_name, True)
            except Exception as e:
                xbmc.log(f"Failed to install addon {addon_name}: {e}", xbmc.LOGERROR)

        # Fallback: Enable the addon directly in the database if not already enabled
        #time.sleep(5)
        #self.enable_addon_in_db(addon_name)
        #time.sleep(5)
        #xbmc.executebuiltin("UpdateLocalAddons")
        #time.sleep(5)
        #self.refresh_addons()

        #Run again services
        #self.run_services()
        
    def refresh_addons(self):
        """Refresh Kodi's addon list so the newly installed addon is detected."""
        xbmc.executebuiltin('UpdateLocalAddons')
        #xbmc.executebuiltin('RefreshWindow(addons)')
        #xbmc.executebuiltin('Container.Refresh')

    def uninstall_addon(self, addon_name):
        xbmc.log(f"Addon {addon_name} to be uninstalled !!! ", xbmc.LOGINFO)
        try:
            if not addon_name.startswith("skin."):
                # Disable the addon
                ####xbmc.executebuiltin(f'DisableAddon({addon_name})')
                ####xbmc.log(f"Addon {addon_name} disabled successfully.", xbmc.LOGINFO)
                self.enable_addon_with_jsonrpc(addon_name, False)

                # Uninstall the addon
                xbmc.executebuiltin(f'UninstallAddon({addon_name})')
                xbmc.log(f"Addon {addon_name} uninstalled successfully.", xbmc.LOGINFO)
                #self.uninstall_addon_with_jsonrpc(addon_name)

                # Delete the addon folder
                addon_path = os.path.join(self.output_path, addon_name)
                if os.path.exists(addon_path):
                    shutil.rmtree(addon_path)
                    xbmc.log(f"Addon folder {addon_path} deleted successfully.", xbmc.LOGINFO)
                else:
                    xbmc.log(f"Addon folder {addon_path} not found for deletion.", xbmc.LOGWARNING)

        except Exception as e:
            xbmc.log(f"Error while uninstalling addon {addon_name}: {e}", xbmc.LOGERROR)

    def install_addon(self, addon_name):
        xbmc.log(f"Addon {addon_name} to be installed !!! ", xbmc.LOGINFO)
        try:
            # Install the addon using Kodi's built-in function
 
            addon_zip_path = os.path.join(self.version_directory, f"{addon_name}.zip")
            #xbmc.executebuiltin(f'InstallAddon({addon_zip_path})')
            if self.install_addon_silently(addon_zip_path, addon_name) == True:
                xbmc.log(f"Addon {addon_zip_path} installed successfully.", xbmc.LOGINFO)
            else:
                xbmc.log(f"Addon {addon_zip_path} not installed !!!", xbmc.LOGERROR)

        except Exception as e:
            xbmc.log(f"Error while installing addon {addon_name}: {e}", xbmc.LOGERROR)

    def install_addon_silently(self, zip_url, addon_name):
        # Step 1: Copy ZIP to Kodi's temp folder (required in Omega)
        temp_path = xbmcvfs.translatePath(f"special://temp/{addon_name}.zip")
        if not xbmcvfs.copy(zip_url, temp_path):
            xbmc.log(f"Addon {zip_url} not copied to {temp_path} !!!", xbmc.LOGERROR)

        # 2. Extract to addons folder
        addon_dir = xbmcvfs.translatePath(f"special://home/addons/")
        with zipfile.ZipFile(temp_path, 'r') as z:
            z.extractall(addon_dir)
            xbmc.log(f"Extracted addon to {addon_dir} ", xbmc.LOGINFO)

        if not xbmcvfs.exists(addon_dir):
            xbmc.log(f"Extracted addon in {addon_dir} doesn't exist !!!", xbmc.LOGERROR)

        # Step 3: Install addon
        if addon_name.startswith("skin."):
            # Enable the addon using JSON-RPC
            #self.disable_skin_change_confirm()
            #Install Addon if it is not already installed
            #if not self.is_addon_installed(addon_name):
            #if not self.is_addon_enabled(addon_name):
            #xbmc.executebuiltin(f'InstallAddon({addon_dir}/{addon_name})')
            xbmc.executebuiltin(f'InstallAddon({addon_name})')
            #xbmc.log(f"InstallAddon({addon_name}) called", xbmc.LOGINFO)
            time.sleep(3)
            self.enable_addon_with_jsonrpc(addon_name,True)
            time.sleep(3)
            #xbmc.executebuiltin(f"Skin.SetString(CurrentSkin,{addon_name})")
            ###time.sleep(10)
            #xbmc.executebuiltin(f'Skin.Set({addon_name})')
            #time.sleep(5)
            ##bmc.executebuiltin(f"Skin.SetString(CurrentSkin,{addon_name})")
            ##time.sleep(10)
            #xbmc.executebuiltin(f"LoadSkin({addon_dir}/{addon_name}, reload)")
            ##xbmc.executebuiltin(f"LoadSkin({addon_name}, reload)")
            ##time.sleep(10)           
            ##xbmc.executebuiltin(f'Skin.Set({addon_name})')
            ##time.sleep(10)
            self.set_kodi_skin(addon_name)
            time.sleep(3)
            #xbmc.executebuiltin(f"SetGUILanguage({addon_name})") 
            #xbmc.executebuiltin("Reset(HomeMenu)")
            xbmc.executebuiltin("ReloadSkin()")  # Ensures proper refresh
            time.sleep(3)
            #xbmc.executebuiltin("Container.Refresh()")
            #time.sleep(5)
            #xbmc.executebuiltin("XBMC.RestartApp()")
            #time.sleep(5)
        else:
            #xbmc.executebuiltin(f'InstallAddon({addon_dir}/{addon_name})')
            ###xbmc.executebuiltin(f'InstallAddon({addon_name})')
            #xbmc.executebuiltin(f'InstallAddon({temp_path})')

            #self.install_addon_with_jsonrpc(f"{addon_dir}{addon_name}")
            #self.install_addon_with_jsonrpc(f"{addon_name}")
            # Enable the addon using JSON-RPC
            #if not addon_name.startswith("service."):
            #    time.sleep(3)
            #    self.enable_addon_with_jsonrpc(addon_name, True)
            #xbmc.executebuiltin(f'EnableAddon({addon_name})')
            # Log success
            #xbmc.log(f"Addon {addon_name} enabled successfully.", xbmc.LOGINFO)
            #time.sleep(10)
            #Refresh video addons
            #if addon_name == "plugin.program.refresh":
            #    xbmc.executebuiltin('RunScript(plugin.program.refresh)')
            pass
        # 4. ALWAYS clean up temp file
        if xbmcvfs.exists(temp_path):
            xbmcvfs.delete(temp_path)
            xbmc.log(f"Temporary ZIP removed: {temp_path}", xbmc.LOGINFO)
        else:
            xbmc.log(f"Temporary ZIP {temp_path} not found !!! ", xbmc.LOGERROR)
            
        return True

    def install_addon_with_jsonrpc(self, addon_id):
        """
        Install the addon using Kodi's JSON-RPC interface.
        """
        try:
            json_rpc_command = {
                "jsonrpc": "2.0",
                "method": "Addons.ExecuteAddon",
                #"params": {"addonid": addon_id, "params": "install"},
                "params": {"addonid": addon_id},
                #"params": {"wait": False,"addonid": addon_id},
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(json_rpc_command))
            xbmc.log(f"JSON-RPC response for installing addon {addon_id}: {response}", xbmc.LOGINFO)

            #Check if error:
            if "error" in response: 
                xbmc.executebuiltin(f"InstallAddon({addon_id})")
                                    
        except Exception as e:
            xbmc.log(f"Error installing addon {addon_id} with JSON-RPC: {e}", xbmc.LOGERROR)

    def uninstall_addon_with_jsonrpc(self, addon_id):
        """
        Install the addon using Kodi's JSON-RPC interface.
        """
        try:
            json_rpc_command = {
                "jsonrpc": "2.0",
                "method": "Addons.Uninstall",
                "params": {"addonid": addon_id},
                #"params": {"addonid": addon_id},
                #"params": {"wait": False,"addonid": addon_id},
                "id": 10
            }
            response = xbmc.executeJSONRPC(json.dumps(json_rpc_command))
            xbmc.log(f"JSON-RPC response for uninstalling addon {addon_id}: {response}", xbmc.LOGINFO)
                                    
        except Exception as e:
            xbmc.log(f"Error uninstalling addon {addon_id} with JSON-RPC: {e}", xbmc.LOGERROR)

    def inspect_jsonrpc(self):
        """
        Install the addon using Kodi's JSON-RPC interface.
        """
        try:
            json_rpc_command = {
                "jsonrpc": "2.0",
                "method": "JSONRPC.Introspect",
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(json_rpc_command))
            xbmc.log(f"JSON-RPC response for inspecting jsonrpc: {response}", xbmc.LOGINFO)
                                    
        except Exception as e:
            xbmc.log(f"Error installing addon {addon_id} with JSON-RPC: {e}", xbmc.LOGERROR)

    def enable_addon_with_jsonrpc(self, addon_id, to_enable):
        """
        Enable the addon using Kodi's JSON-RPC interface.
        """
        try:
            json_rpc_command = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {
                    "addonid": addon_id,
                    "enabled": to_enable
                },
                "id": 2
            }
            response = xbmc.executeJSONRPC(json.dumps(json_rpc_command))
            xbmc.log(f"JSON-RPC response for enabling addon {addon_id} {to_enable}: {response}", xbmc.LOGINFO)
            
            #Check if error:
            if "error" in response: 
                time.sleep(5)
                if to_enable:
                    xbmc.log(f"error detected in rpc response, enabling addon by other ways", xbmc.LOGINFO)
                    xbmc.executebuiltin(f"EnableAddon({addon_id})")
                    #self.enable_addon_in_db(addon_name)
                else:
                    xbmc.log(f"error detected in rpc response, disabling addon by other ways", xbmc.LOGINFO)
                    xbmc.executebuiltin(f"DisableAddon({addon_id})")
                
        except Exception as e:
            xbmc.log(f"Error enabling addon {addon_id} with JSON-RPC: {e}", xbmc.LOGERROR)

    def disable_addon_with_jsonrpc(self, addon_id):
        """
        Disable the addon using Kodi's JSON-RPC interface.
        """
        try:
            json_rpc_command = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {
                    "addonid": addon_id,
                    "enabled": False
                },
                "id": 3
            }
            response = xbmc.executeJSONRPC(json.dumps(json_rpc_command))
            xbmc.log(f"JSON-RPC response for disabling addon {addon_id}: {response}", xbmc.LOGINFO)
                                    
        except Exception as e:
            xbmc.log(f"Error enabling addon {addon_id} with JSON-RPC: {e}", xbmc.LOGERROR)

    def enable_addon_in_db(self, addon_id, to_enable):
        """
        Enable the addon directly in Kodi's database as a fallback.
        """
        try:
            # Locate Kodi's userdata folder and Addons   database
            kodi_user_data = xbmcvfs.translatePath("special://userdata")
            addons_db_path = os.path.join(kodi_user_data, "Database", "Addons33.db")  # Adjust version if needed

            if not os.path.exists(addons_db_path):
                xbmc.log("Addons database not found!", xbmc.LOGERROR)
                return

            # Connect to the SQLite database
            conn = sqlite3.connect(addons_db_path)
            cursor = conn.cursor()

            # Update the enabled state of the addon
            if to_enable:
                cursor.execute("UPDATE installed SET enabled = 1 WHERE addonID = ?", (addon_id,))
            else:
                cursor.execute("UPDATE installed SET enabled = 0 WHERE addonID = ?", (addon_id,))
            conn.commit()

            xbmc.log(f"Addon {addon_id} enabled {to_enable} in database.", xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f"Error enabling addon {addon_id} in database: {e}", xbmc.LOGERROR)
        finally:
            if conn:
                conn.close()

    def is_addon_enabled(self, addon_id):
        """
        Check if a Kodi addon is enabled using executeJSONRPC.
        
        Args:
            addon_id (str): The ID of the addon (e.g., "service.xbmc.versioncheck")
        
        Returns:
            bool: True if enabled, False if disabled or not found
        """
        json_rpc = json.dumps({
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {
                "addonid": addon_id,
                "properties": ["enabled"]
            },
            "id": 4
        })
        
        try:
            result = xbmc.executeJSONRPC(json_rpc)
            result_json = json.loads(result)
            return result_json.get("result", {}).get("addon", {}).get("enabled", False)
        except Exception as e:
            print(f"Error checking addon status: {e}")
            return False

    def is_addon_installed(self, addon_id):
        """
        Check if a Kodi addon is installed (even if disabled) using JSON-RPC.
        
        :param addon_id: The ID of the addon (e.g., "plugin.video.youtube")
        :return: True if installed, False otherwise
        """
        json_rpc = json.dumps({
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {
                "addonid": addon_id
            },
            "id": 5
        })

        response = xbmc.executeJSONRPC(json_rpc)
        
        try:
            result = json.loads(response)
            xbmc.log(f"JSON-RPC response for is_addon_installed {addon_id}: {response}", xbmc.LOGINFO)
            if "result" in result and "addon" in result["result"]:
                return True  # Addon exists
        except json.JSONDecodeError:
            xbmc.log(f"JSON decoding error for addon check: {addon_id}", xbmc.LOGERROR)

        return False  # Addon is not installed or an error occurred

    def stop_services(self):
        """Stop all services that start with 'service.' from the list."""
        xbmc.log(f"Stopping services... !!! ", xbmc.LOGINFO)

        # Loop through the list in reverse order
        for addon_name in reversed(ADDON_NAME_LIST):
            if addon_name.startswith("service."):
                # Get the addon object
                addon_status = self.is_addon_enabled(addon_name)
                #addon = xbmcaddon.Addon(addon_name)
                
                # Check if the addon is enabled and stop it
                while addon_status:
                    xbmc.log(f"Stopping service: {addon_name}", xbmc.LOGINFO)
                    #xbmc.executebuiltin(f"StopAddon {addon_name}")
                    xbmc.executebuiltin(f"AbortScript({addon_name})")
                    self.disable_addon_with_jsonrpc(addon_name)
                    # Get again the addon object
                    addon_status = self.is_addon_enabled(addon_name)
                    if addon_status:
                        xbmc.sleep(1000)
                    else:
                        xbmc.log(f"Service: {addon_name} stopped !!!", xbmc.LOGINFO)


    def run_services(self):
        """Run all services that start with 'service.' from the list."""
        # Loop through the list in correct order
        for addon_name in ADDON_NAME_LIST:
            if addon_name.startswith("service."):
                # Start the addon
                xbmc.log(f"Starting service: {addon_name}", xbmc.LOGINFO)
                self.enable_addon_with_jsonrpc(addon_name, True)
                #xbmc.executebuiltin(f'RunScript({addon_name})')   


    def set_kodi_skin(self, skin_name):
        """Set Kodi skin using JSON-RPC."""
        json_rpc = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": "lookandfeel.skin",
                "value": skin_name
            },
            "id": 6
        }
        response = xbmc.executeJSONRPC(json.dumps(json_rpc))
        xbmc.log(f"Skin changed: {response}", xbmc.LOGINFO)

    def disable_skin_change_confirm(self):
        json_rpc = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": "lookandfeel.skinconfirm",
                "value": False
            },
            "id": 7
        }
        response = xbmc.executeJSONRPC(json.dumps(json_rpc))
        xbmc.log(f"disable_skin_change_confirm: {response}", xbmc.LOGINFO)

    def disable_all_notifications(self):
        json_rpc = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": "addonupdates.notification",
                "value": False
            },
            "id": 8
        }
        response = xbmc.executeJSONRPC(json.dumps(json_rpc))
        xbmc.log(f"disable_all_notifications: {response}", xbmc.LOGINFO)
