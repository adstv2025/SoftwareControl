# -----------------------------------------------------------------------------
# Name: Nejib MELKI
# Project: System setup program
# File: system_setup.py
#
# Copyright (c) 2025 Nejib MELKI
# All rights reserved.
#
# This software and its source code are the property of Nejib MELKI. Unauthorized
# copying, modification, distribution, or use of this software, in whole or in
# part, is strictly prohibited without the explicit written permission of 
# Nejib MELKI.
#
# This software is provided 'as-is', without any express or implied warranty.
# In no event shall the author be held liable for any damages arising from
# the use of this software.
# -----------------------------------------------------------------------------

import os
import xbmcgui
import shutil
import xbmcvfs
import platform
import xbmc
import time

from .addons_install import AddonsInstall
from .addons_install_lite import AddonsInstallLite
from .splash_install import SplashInstall
from .boot_animation_install import BootAnimationInstall
from .video_db_install import VideoDbInstall

class SystemSetup:
    def __init__(self, selected_directory):
        self.selected_directory = selected_directory
    
    def get_os_name(self):
        """
        Detects and returns the current operating system name.
        """
        os_name = platform.system()
        if os_name == "Linux" and "ANDROID_ROOT" in os.environ:
            return "Android"
        return os_name

    def system_setup_execute(self, is_first_install = True):

        addon_path = xbmcvfs.translatePath("special://home/addons/plugin.program.setup")
        os_name = self.get_os_name()
        
        if os_name == "Android":
            new_image_path = f"{addon_path}/resources/Images/background.png"
        else:
            new_image_path = f"{addon_path}/resources/Images/background.jpg"

        splash_install = SplashInstall(self.selected_directory)
        
        splash_install.change_kodi_splash(new_image_path)

        #self.change_kodi_splash(new_image_path)
        #self.change_boot_animation(new_image_path)

        boot_animation_install = BootAnimationInstall(self.selected_directory)
        #boot_animation_install.change_boot_animation(new_image_path)
        
        #System addon list installation
        addons_install_lite = AddonsInstallLite(self.selected_directory)
        #addons_install.uninstall_addons_list()
        if is_first_install:
            addons_install_lite.stop_services()
        #addons_install.clear_disabled_addon_flags()
        
        video_db_install = VideoDbInstall(self.selected_directory)
        video_db_install.copy_video_directory()

        addons_install_lite.install_addons_list()
        
        if is_first_install:
            addons_install_lite.run_services()

