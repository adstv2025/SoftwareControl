# -----------------------------------------------------------------------------
# Name: Nejib MELKI
# Project: Addons install - lite version
# File: addons_install_lite.py
#
# Copyright (c) 2025 Nejib MELKI
# All rights reserved.
#
# This software and its source code are the property of Nejib MELKI. Unauthorized
# copying, modification, distribution, or use of this software, in whole or in
# part, is strictly prohibited without the explicit written permission of 
# Nejib MELKI.
#
# This software is provided 'as-is', without any express or implied warranty.
# In no event shall the author be held liable for any damages arising from
# the use of this software.
# -----------------------------------------------------------------------------

import os
import shutil
import json
import xbmcgui
import xbmcvfs
import platform
import xbmc
import xbmcaddon
#import time

import sqlite3
import zipfile

ADDON_NAME_LIST = [
                    "script.module.systemsetup",
                    "script.module.addonssetup",
                    "script.module.upgrade",
                    "plugin.program.setup",
                    "plugin.program.refresh",
                    "service.autoplay",
                    "service.autoupdate",
#                    "service.watchdog",
                    "skin.AdsTV"
                  ]

class AddonsInstallLite:
    def __init__(self, version_directory):
        self.version_directory = version_directory
        self.output_path = xbmcvfs.translatePath('special://home/addons/') # Kodi's addon directory

    def get_zip_files(self, directory):
        """Returns a list of all .zip files in the selected directory."""
        if not os.path.exists(directory):
            return []  # Return empty list if directory doesn't exist
        
        return [f for f in os.listdir(directory) if f.lower().endswith('.zip')]


    def install_addons_list(self):
        # Retrieve .zip files in the given directory
        zip_files = self.get_zip_files(self.version_directory)
        self.need_refresh = False
        for addon_name in ADDON_NAME_LIST:
            try:
                addon_name_zip = f"{addon_name}.zip"
                if addon_name_zip in zip_files:
                    self.install_addon(addon_name)
            except Exception as e:
                xbmc.log(f"Failed to install addon {addon_name}: {e}", xbmc.LOGERROR)
        if self.need_refresh:
            xbmc.executebuiltin('UpdateLocalAddons')

    def install_addon(self, addon_name):
        xbmc.log(f"Addon {addon_name} to be installed !!! ", xbmc.LOGINFO)
        try:
            addon_zip_path = os.path.join(self.version_directory, f"{addon_name}.zip")
            if self.install_addon_silently(addon_zip_path, addon_name) == True:
                xbmc.log(f"Addon {addon_zip_path} installed successfully.", xbmc.LOGINFO)
            else:
                xbmc.log(f"Addon {addon_zip_path} not installed !!!", xbmc.LOGERROR)

        except Exception as e:
            xbmc.log(f"Error while installing addon {addon_name}: {e}", xbmc.LOGERROR)

    def install_addon_silently(self, zip_url, addon_name):
        # Step 1: Copy ZIP to Kodi's temp folder (required in Omega)
        temp_path = xbmcvfs.translatePath(f"special://temp/{addon_name}.zip")
        if not xbmcvfs.copy(zip_url, temp_path):
            xbmc.log(f"Addon {zip_url} not copied to {temp_path} !!!", xbmc.LOGERROR)

        #Remove the old folder
        # Delete the addon folder
        addon_path = os.path.join(self.output_path, addon_name)
        if os.path.exists(addon_path):
            shutil.rmtree(addon_path)
            xbmc.log(f"Addon folder {addon_path} deleted successfully.", xbmc.LOGINFO)
        else:
            xbmc.log(f"Addon folder {addon_path} not found for deletion.", xbmc.LOGWARNING)

        # 2. Extract to addons folder
        addon_dir = xbmcvfs.translatePath(f"special://home/addons/")
        with zipfile.ZipFile(temp_path, 'r') as z:
            z.extractall(addon_dir)
            xbmc.log(f"Extracted addon to {addon_dir} ", xbmc.LOGINFO)

        if not xbmcvfs.exists(addon_dir):
            xbmc.log(f"Extracted addon in {addon_dir} doesn't exist !!!", xbmc.LOGERROR)

        # Step 3: Install addon
        if addon_name.startswith("skin."):
            self.enable_addon_with_jsonrpc(addon_name,False)
            xbmc.sleep(3000)
            xbmc.executebuiltin(f'InstallAddon({addon_name})')
            xbmc.sleep(3000)
            self.enable_addon_with_jsonrpc(addon_name,True)
            xbmc.sleep(3000)
            self.set_kodi_skin(addon_name)
            xbmc.sleep(3000)
            xbmc.executebuiltin("ReloadSkin()")  # Ensures proper refresh
            xbmc.sleep(3000)
        else:
            if self.is_addon_installed(addon_name):
                xbmc.executebuiltin(f'InstallAddon({addon_name})')
                self.need_refresh = True
                
        # 4. ALWAYS clean up temp file
        if xbmcvfs.exists(temp_path):
            xbmcvfs.delete(temp_path)
            xbmc.log(f"Temporary ZIP removed: {temp_path}", xbmc.LOGINFO)
        else:
            xbmc.log(f"Temporary ZIP {temp_path} not found !!! ", xbmc.LOGERROR)
            
        return True

    def enable_addon_with_jsonrpc(self, addon_id, to_enable):
        """
        Enable the addon using Kodi's JSON-RPC interface.
        """
        try:
            json_rpc_command = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {
                    "addonid": addon_id,
                    "enabled": to_enable
                },
                "id": 2
            }
            response = xbmc.executeJSONRPC(json.dumps(json_rpc_command))
            xbmc.log(f"JSON-RPC response for enabling addon {addon_id} {to_enable}: {response}", xbmc.LOGINFO)
            
            #Check if error:
            if "error" in response: 
                #time.sleep(5)
                xbmc.sleep(5000)
                if to_enable:
                    xbmc.log(f"error detected in rpc response, enabling addon by other ways", xbmc.LOGINFO)
                    xbmc.executebuiltin(f"EnableAddon({addon_id})")
                else:
                    xbmc.log(f"error detected in rpc response, disabling addon by other ways", xbmc.LOGINFO)
                    xbmc.executebuiltin(f"DisableAddon({addon_id})")
                
        except Exception as e:
            xbmc.log(f"Error enabling addon {addon_id} with JSON-RPC: {e}", xbmc.LOGERROR)

    def is_addon_enabled(self, addon_id):
        """
        Check if a Kodi addon is enabled using executeJSONRPC.
        
        Args:
            addon_id (str): The ID of the addon (e.g., "service.xbmc.versioncheck")
        
        Returns:
            bool: True if enabled, False if disabled or not found
        """
        json_rpc = json.dumps({
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {
                "addonid": addon_id,
                "properties": ["enabled"]
            },
            "id": 4
        })
        
        try:
            result = xbmc.executeJSONRPC(json_rpc)
            result_json = json.loads(result)
            return result_json.get("result", {}).get("addon", {}).get("enabled", False)
        except Exception as e:
            print(f"Error checking addon status: {e}")
            return False

    def is_addon_installed(self, addon_id):
        """
        Check if a Kodi addon is installed (even if disabled) using JSON-RPC.
        
        :param addon_id: The ID of the addon (e.g., "plugin.video.youtube")
        :return: True if installed, False otherwise
        """
        json_rpc = json.dumps({
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {
                "addonid": addon_id
            },
            "id": 5
        })

        response = xbmc.executeJSONRPC(json_rpc)
        
        try:
            result = json.loads(response)
            xbmc.log(f"JSON-RPC response for is_addon_installed {addon_id}: {response}", xbmc.LOGINFO)
            if "result" in result and "addon" in result["result"]:
                return True  # Addon exists
        except json.JSONDecodeError:
            xbmc.log(f"JSON decoding error for addon check: {addon_id}", xbmc.LOGERROR)

        return False  # Addon is not installed or an error occurred

    def stop_services(self):
        """Stop all services that start with 'service.' from the list."""
        xbmc.log(f"Stopping services... !!! ", xbmc.LOGINFO)

        # Loop through the list in reverse order
        for addon_name in reversed(ADDON_NAME_LIST):
            if addon_name.startswith("service."):
                # Get the addon object
                addon_status = self.is_addon_enabled(addon_name)
                #addon = xbmcaddon.Addon(addon_name)
                
                # Check if the addon is enabled and stop it
                while addon_status:
                    xbmc.log(f"Stopping service: {addon_name}", xbmc.LOGINFO)
                    #xbmc.executebuiltin(f"StopAddon {addon_name}")
                    xbmc.executebuiltin(f"AbortScript({addon_name})")
                    xbmc.sleep(1000)
                    self.enable_addon_with_jsonrpc(addon_name, False)
                    # Get again the addon object
                    addon_status = self.is_addon_enabled(addon_name)
                    if addon_status:
                        xbmc.sleep(1000)
                    else:
                        xbmc.log(f"Service: {addon_name} stopped !!!", xbmc.LOGINFO)


    def run_services(self):
        """Run all services that start with 'service.' from the list."""
        # Loop through the list in correct order
        for addon_name in ADDON_NAME_LIST:
            if addon_name.startswith("service."):
                # Start the addon
                xbmc.log(f"Starting service: {addon_name}", xbmc.LOGINFO)
                self.enable_addon_with_jsonrpc(addon_name, True)
                #xbmc.executebuiltin(f'RunScript({addon_name})')   

    def set_kodi_skin(self, skin_name):
        """Set Kodi skin using JSON-RPC."""
        json_rpc = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": "lookandfeel.skin",
                "value": skin_name
            },
            "id": 6
        }
        response = xbmc.executeJSONRPC(json.dumps(json_rpc))
        xbmc.log(f"Skin changed: {response}", xbmc.LOGINFO)
